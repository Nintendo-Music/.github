# Changelog

## [1.0.0] - 2024-10-30
### Added
- Initialized main app setup for YouTube Premium APK.
- Implemented ad-free experience, background play, and offline download functionalities.
- Created customizable settings for interface and playback.

### Changed
- Updated UI to enhance user experience on mobile devices.

## [0.1.0] - 2024-10-15
### Added
- Initial setup of the repository with core files and README.
